export default function NavBar(){
    return (
        <p>
        <a href="/component1">Component-1</a> |
        <a href="/component2"> Component-2</a> |
        <a href="/component3"> Component-3</a> |
        <a href="/component4"> Component-4</a> 
        </p>
    )
}