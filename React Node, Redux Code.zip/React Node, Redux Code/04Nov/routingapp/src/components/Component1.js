export default function Component1(){
    return (
        <h1>Component 1</h1>
    )
}