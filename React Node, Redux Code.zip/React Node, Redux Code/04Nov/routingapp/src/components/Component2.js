export default function Component2(){
    return (
        <h1>Component 2</h1>
    )
}