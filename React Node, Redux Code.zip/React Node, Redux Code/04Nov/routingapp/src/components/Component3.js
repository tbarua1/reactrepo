export default function Component3(){
    return (
        <h1>Component 3</h1>
    )
}