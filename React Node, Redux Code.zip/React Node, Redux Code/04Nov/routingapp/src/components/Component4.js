export default function Component4(){
    return (
        <h1>Component 4</h1>
    )
}