import './App.css';
import Component1 from './components/Component1';
import Component2 from './components/Component2';
import Component3 from './components/Component3';
import Component4 from './components/Component4';
import { BrowserRouter, Router, Routes, Route} from 'react-router-dom';
import NavBar from './components/NavBar';

function App() {
  return (
    <BrowserRouter>
    <div className="App">
      <header className="App-header">
       <NavBar></NavBar>
       <Routes>
         <Route exact path='/component1' element={<Component1></Component1>}></Route>
         {/* http://localhost:3000/component1/1/tarkesh/ , 
         even after andding anythin inthe URL it will redirect to that particular page*/}
         <Route exact path='/component2' element={<Component2></Component2>}></Route>
         <Route exact path='/component3' element={<Component3></Component3>}></Route>
         <Route exact path='/component4' element={<Component4></Component4>}></Route>
       </Routes>
      </header>
    </div>
    </BrowserRouter>
  );
}

export default App;
