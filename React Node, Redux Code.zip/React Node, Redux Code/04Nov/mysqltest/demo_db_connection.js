var mysql = require("mysql")
var con =mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"yourdb"
})
con.connect(function(err){
    if(err) throw err
    console.log("Database Connected")
    // con.query("create database testdb", function(error, result){
    //     if(error) throw error
    //     console.log("Result  : "+result)
    // })
    con.query("select * from employee", function(error, result, fields){
        if(error) throw error
        for(var r in result){
            console.log(result[r].name + " - "+result[r].phone)
        }
       // console.log("Result : "+result)
        //console.log("Fields  : "+fields)
    })
})