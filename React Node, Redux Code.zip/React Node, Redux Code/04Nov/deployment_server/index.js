// npm install express
const express=require("express") // importing express library
const path = require("path") // importing path library
const app = express() // creating server app 
app.use(express.static(path.join(__dirname, "build"))) 
// build folder as home folder
app.get("/", function(req, res){
    res.sendFile(path.join(__dirname, "build", "index.html"))
}) // specifying default url to open with html page
app.listen(8080)  // specifying port number to start server
console.log("Server has been started on port 8080")