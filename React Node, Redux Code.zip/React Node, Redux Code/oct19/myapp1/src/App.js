import logo from './logo.svg';
import './App.css';
import MyComponent from "./components/MyClassComponent"
import SampleProp from "./components/PropsDemo"
import Person from "./components/PropsinClass"
function App() { // my basic component
  // This section only for JavaScript
  const satement=<h1>Content on App Component</h1>
  const x=10
  const person={"name":"Tarkeshwar","phone":3433453,"city":"New Delhi"}
  const person1 = <Person character = "good"></Person>
  return (
    // JSX section goes here
    <div className="App">
      <header className="App-header">
        {person1}
        <h1>{x} Hello All, I am learning React JSX {person.name}</h1>
        {satement} 
        {5+50}
        <MyComponent></MyComponent>
        {/* Props are immutable, used to pass data to component */}
        <SampleProp name="Mr ABC" phone="343434" city="Bangalore"></SampleProp>
      </header>
      
    </div>
  );
}

export default App;
