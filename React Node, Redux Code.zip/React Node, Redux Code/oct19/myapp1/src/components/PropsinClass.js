import React from 'react';
import Garage from './Garage';
class Person extends React.Component {
    render() {
        return (
            <div>
                <label>I am a {this.props.character} person.</label>
                <Garage></Garage>
            </div>
        );
    }
}
export default Person;
