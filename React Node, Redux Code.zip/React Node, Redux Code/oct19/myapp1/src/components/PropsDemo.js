export default function SampleProp(props) {
    return (
        <>
            <h1>Hi, {props.name}</h1>
            <p>i lives in {props.city} and phone number is {props.phone}</p>
        </>
    )
}