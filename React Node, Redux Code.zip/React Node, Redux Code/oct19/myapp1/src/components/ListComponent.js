import "../css/table.css"
//Functional component
export default function ListComp() {
    const x = 11;
    let text = "Goodbye";
    if (x < 10) {
        text = "Hello";
    }
    const ternery=<h1>{x>5?`Hi`:`Hello`}</h1>
    const myElement = <h1>{text}</h1>;
    const salaryPaid = false
    return (
        <div>
            {ternery}
            {myElement}
            {/* <p class="fdfd"></p> */}
            <p className="mysample">{salaryPaid ? "Yes I got Salary" : "Salary not received"}</p>
            <ul id="myid">
                <li>One</li>
                <li>Two</li>
                <li>Three</li>
            </ul>
            <ol>
                <li>One</li>
                <li>Two</li>
                <li>Three</li>
            </ol>
        </div>
    )
}