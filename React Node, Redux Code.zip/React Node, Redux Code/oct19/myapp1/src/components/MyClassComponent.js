import React from "react"
//Class component
class MyComponent extends React.Component {
    render() {
        return (
        <>
        <h1>Tarkesh</h1>
        <p>Hello Hi, How are you</p>
        </>)
    }
}
export default MyComponent;

// Functional Component
// export default function MyComponent{
// return(<>H1</>)
// }
