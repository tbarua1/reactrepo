// import React from 'react';
// class Person extends React.Component {
//     // Constructor is used to create an object
//     constructor(props) {
//         super(props);
//         this.state = {
//             age: 0,
//             incrementAge = this.incrementAge.bind(this)
//         }
//         // method to increase the number
//         function incrementAge() {
//             this.setState({
//                 age: this.state.age + 1,
//             });
//         }
       
//     }
//     render(){
//         return (
//             <div>
//                 <label>My age is: {this.state.age}</label>
//                 <button onClick={this.incrementAge}>Grow me older !!</button>
//             </div>
//             );
//     };
// }
// export default Person;