export default function Car(props) {
    return <h2>I am a { props.brand }!</h2>;
  }