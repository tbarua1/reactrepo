import Car from "./Car"
export default function Garage() {
    return (
      <>
      <h1>Who lives in my garage?</h1>
      <Car brand="Ford" /> 
      {/* Passing data(Ford) to car component */}
      </>
    );
  }