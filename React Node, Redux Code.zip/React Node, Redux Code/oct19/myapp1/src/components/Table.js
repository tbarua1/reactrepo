import "../css/table.css"
export default function Table() {
    const who = "Dr Tarkeshwar Barua";
    function who1() {
        return "World";
    }
    const greet = <h1>Hello {who}!</h1>;
    const greet1 = <h1>Hello {who1()}!</h1>;
    const tags = (
        <>        <h1>Hello World!</h1>
        <h3>This is my special list:</h3>
        <ul>
          <li>Once</li>
          <li>Twice</li>
        </ul></>
      );
    return ( // blank tag is known as fragment
        <> 
            {tags}
            {greet}
            {greet1}
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Phone</th>
                    </tr></thead><tbody>
                    <tr>
                        <td>Dr Tarkeshwar Barua</td>
                        <td>45456456456</td>
                    </tr></tbody>
                <tfoot>
                    <tr>
                        <td>Dr Tarkeshwar Barua</td>
                        <td>45456456456</td>
                    </tr>

                </tfoot>
            </table>
        </>

    )
}
//export default Table;