declare module TestVar1 { 
    export class Calc { 
       doSum(num1:number, num2:number) : number; 
    }
 }