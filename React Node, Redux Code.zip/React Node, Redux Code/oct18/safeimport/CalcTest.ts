/// <reference path = "Calc.d.ts" /> 
var obj = new TestVar.Calc(); 
console.log(obj.doSum(10,20));