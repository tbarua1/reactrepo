var TestVar;  
function myfunc(TestVar) {  
   var Calc = (function () { 
      function Calc() { 
      } 
      Calc.prototype.doSum = function (num1, num2) {
         return num1 + num2;
      }
   }
}