export default  interface IShowDetails { 
    display(); 
 }