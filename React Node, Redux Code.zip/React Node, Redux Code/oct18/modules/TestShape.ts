import showDetails from "./IShowDetails"; 
import student from "./Student"; 
import { Student } from "./Student";
import teacher from "./Teacher";   
import { Teacher } from "./Teacher";
function showAllDetails(detailsToShow: showDetails) {
   detailsToShow.display(); 
}  
showAllDetails(new Student); 
showAllDetails(new Teacher);