"use strict";
exports.__esModule = true;
exports.Student = exports.Student1 = void 0;
//import showDetails =require("./IShowDetails"); 
var Student1 = /** @class */ (function () {
    function Student1() {
    }
    Student1.prototype.display = function () {
        console.log("Student Details");
    };
    return Student1;
}());
exports.Student1 = Student1;
//import showDetails = require("./IShowDetails"); 
var Student = /** @class */ (function () {
    function Student() {
    }
    Student.prototype.display = function () {
        console.log("Student Details");
    };
    return Student;
}());
exports.Student = Student;
