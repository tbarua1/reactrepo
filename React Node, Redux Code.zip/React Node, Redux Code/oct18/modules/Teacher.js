"use strict";
exports.__esModule = true;
exports.Teacher = void 0;
var Teacher = /** @class */ (function () {
    function Teacher() {
    }
    Teacher.prototype.display = function () {
        console.log("Teacher details.");
    };
    return Teacher;
}());
exports.Teacher = Teacher;
