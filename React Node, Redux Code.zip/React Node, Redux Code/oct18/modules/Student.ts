import showDetails from "./IShowDetails"
//import showDetails =require("./IShowDetails"); 
export default class Student1 implements showDetails { 
   public display() { 
      console.log("Student Details"); 
   } 
}
