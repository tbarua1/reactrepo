//import showDetails *;// = require("./IShowDetails"); 
import showDetails from "./IShowDetails";
export default class Teacher implements showDetails { 
   public display() { 
      console.log("Teacher details."); 
   } 
}