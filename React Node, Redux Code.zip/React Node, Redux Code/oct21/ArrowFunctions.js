function hello(){
    console.log( "Good Afternoon from hello function")
    return "Hello"
}
let hello1 = function() {
    console.log( "Hello i am from hello1")
    return "Hello1"
  }
  let  hello2 = () => {
      console.log("I am from Hello2")
    return "Hello World!";
  }
  let hello3 = () => "Hello World! from hello3";
  let hello4 = (val) => "Hello " + val;
  let hello5 = val => "Hello " + val;
  hello()
  hello1()
  hello2()
  console.log(hello3())
  console.log(hello4("Tarkeshwar"))
  console.log(hello5("Barua"))