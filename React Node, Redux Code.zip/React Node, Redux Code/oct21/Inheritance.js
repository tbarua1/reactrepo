//This is a parent class
class Car {
    constructor(name) {
      this.brand = name;
    }
    present() {
      return 'I have a ' + this.brand;
    }
  }
  // This is a child class of calss Car
  class Model extends Car {
    constructor(name, mod) {
      super(name);
      this.model = mod;
    }  
    show() {
        return this.present() + ', it is a ' + this.model
    }
  }
  const mycar = new Model("Ford", "Mustang");
  let msg1=mycar.show();
  console.log(msg1);
  let msg2=mycar.present() // inherited from Car class 
  console.log(msg2);