// here person is an object
const person = {
    name : 'Jack',
    age: 25,

    // this inside method
    // this refers to the object itself
    greet() {
        console.log(this);
        console.log(this.age);

        // inner function
        let innerFunc = () => {
        
            // this refers to the global object
            console.log(this);
            console.log(this.age);   
        }
        innerFunc();
    }
}
//let person=new Person() this is only needed in the case of class
person.greet();