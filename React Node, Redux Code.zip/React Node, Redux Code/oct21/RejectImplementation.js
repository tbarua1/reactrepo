function getUsers() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            // resolve([
            //     { username: 'tbarua1', email: 'tbarua1@gmail.com' },
            //     { username: 'tarkeshwar', email: 'tarkeshwar.b@regexsoftware.com' },
            // ]);
            reject('Failed to the user list');
        }, 2000);
    });
}

function onFulfilled(users) {
    console.log(users);
}

function onRejected(error) {
    console.log(error);
}
const promise = getUsers();
promise.then(onFulfilled, onRejected);