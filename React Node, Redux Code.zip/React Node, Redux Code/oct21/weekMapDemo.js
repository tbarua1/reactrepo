let empMap = new WeakMap();
// emp.set(10,'Sachin');
// Error as keys should be object
let e1 = { ename: 'Kiran' },
    e2 = { ename: 'Kannan' },
    e3 = { ename: 'Mohtashim' }

empMap.set(e1, 1001);
empMap.set(e2, 1002);
empMap.set(e3, 1003);

console.log(empMap)
console.log(empMap.get(e2))
console.log(empMap.has(e2))
empMap.delete(e1)