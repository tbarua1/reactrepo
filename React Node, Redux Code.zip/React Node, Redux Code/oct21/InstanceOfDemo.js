class Car{
    // brandName is parameter in the constructor and this.brandName represents instance variable
    // instance variables will be created automatically ondemand
    constructor(brandName){
        this.brandName=brandName
    }
    displayMyCar(){  // method of the class car
        console.log(this.brandName+" is my car")
    }
}
class Person{ } 
var obj = new Person() 
let obj1=new Car();
// instanceof is a keyword in Javascript
var isPerson = obj instanceof Person; 
console.log(" obj is an instance of Person " + isPerson);
console.log("Obj1 is an object of Person class "+ (obj1 instanceof Person));
