class Student {
    constructor(rno,fname,lname){
       this.rno = rno
       this.fname = fname
       this.lname = lname
       console.log('inside constructor')
    }
    // set rollno(newRollno){
    //     console.log("inside setter")
    //     this.rno = newRollno
    //  }
    get fullName(){
       console.log('inside getter')
       return this.fname + " - "+this.lname
    }
 }
 let s1 = new Student(1,'Tarkeshwar','Barua')
 console.log(s1)
 s1.rollno(200)
 //getter is called
 console.log(s1.fullName)