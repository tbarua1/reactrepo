let names = new Set(['A','B','C','D']);
console.log(names.delete('A'))
console.log(names)