let e1 = { ename: 'A' }
let e2 = { ename: 'B' }
let e3 = { ename: 'C' }

let emps = new WeakSet();
emps.add(e1);
emps.add(e2)
    .add(e3);

console.log(emps)
console.log(emps.has(e1))
emps.delete(e1);
console.log(emps)