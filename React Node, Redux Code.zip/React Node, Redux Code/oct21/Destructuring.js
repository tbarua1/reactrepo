function calculate(a, b) {
    const add = a + b;
    const subtract = a - b;
    const multiply = a * b;
    const divide = a / b;
    const modulo=a%b;
  
    return [add, subtract, multiply, divide, modulo];
  }
  
  const [add, subtract, multiply, divide, modulo] = calculate(4, 7);
  console.log(add)
  console.log(subtract)
  console.log(multiply)
  console.log(divide)
  console.log(modulo)