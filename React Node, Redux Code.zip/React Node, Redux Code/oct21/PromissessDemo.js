function getUsers() {
    return [
        { username: 'tbarua1', email: 'tbarua1@gmail.com' },
        { username: 'tarkeshwar', email: 'tarkeshwar.b@regexsoftware.com' },
    ];
}

function findUser(username) {
    const users = getUsers();
                            //themp user
    const user = users.find((userTemp) => userTemp.username === username); 
    // comparing with parameter passed 
    return user;
}
console.log(findUser('tbarua1'));
console.log(findUser('tbarua1').username);
console.log(findUser('tbarua1').email);