const myArray = ['apple', 'banana', 'orange']; // list/array will no change in premitive datatype'

myArray.push("Papaya")
let myArray1 = ['apple', 'banana', 'orange']; // list/array will change
myArray1.push("Papaya")
// The .map() method allows you to run a function on each item in the array, returning a new array as the result.
const myList = myArray.map((item) => `< p > ${ item } < /p>`);
console.log(myList);
console.log(myArray1)
console.log(myArray)