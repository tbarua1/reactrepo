function getUsers(callback) {
    setTimeout(() => {
        callback([
            { username: 'tbarua1', email: 'tbarua1@gmail.com' },
            { username: 'tarkeshwar', email: 'tarkeshwar.b@regexsoftware.com' },
        ]);
    }, 5000);
}

function findUser(username, callback) {
    getUsers((users) => {
        const user = users.find((user) => user.username === username);
        callback(user);
    });
}

findUser('tbarua1', console.log);