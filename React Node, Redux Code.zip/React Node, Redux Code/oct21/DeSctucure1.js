let list=["One","Two","Three", "Four"]
console.log("Index - 0 "+list[0])   // traditional approach to destrucre data
console.log("Index - 0 "+list[3])
//ES6 apploach 
let [a,,,d]=list
console.log(a)
//console.log(b)
//console.log(c)
console.log(d) 