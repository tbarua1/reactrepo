class StaticMem { 
    static disp() { 
       console.log("Static Function called") 
    }
    disp1() { 
        console.log("Non-Static Function called") 
     } 
 } 
 StaticMem.disp()
 let testVariable=new StaticMem();
 testVariable.disp1()