function getUsers() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve([
                { username: 'tbarua1', email: 'tbarua1@gmail.com' },
                { username: 'tarkeshwar', email: 'tarkeshwar.b@regexsoftware.com' },
            ]);
        }, 1000);
    });
}

const promise = getUsers();
// promiss call with arrow function
promise.then((users) => {
    console.log(users);
});