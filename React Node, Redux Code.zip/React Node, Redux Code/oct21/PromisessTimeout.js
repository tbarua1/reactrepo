function getUsers1() {
    let users = [];

    // delay 1 second (1000ms)
    setTimeout(() => {
        users = [
            { username: 'tbarua1', email: 'tbarua1@gmail.com' },
            { username: 'tarkeshwar', email: 'tarkeshwar.b@regexsoftware.com' },
        ];
    }, 1000);

    return users;
}

function findUser(username) {
    const users = getUsers1();
    const user = users.find((user) => user.username === username);
    return user;
}
console.log(findUser('tbarua1'));