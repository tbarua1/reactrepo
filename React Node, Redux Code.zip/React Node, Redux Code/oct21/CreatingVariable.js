var x = 5.6; // Older approach, creating global variable
let x = 5.6; // let is the block scoped version of var, and is limited to the block (or expression) where it is defined.
const x = 5.6;   //const is a variable that once it has been created, its value can never change.