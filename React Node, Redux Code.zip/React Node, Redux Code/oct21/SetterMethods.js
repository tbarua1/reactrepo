class Student {
    constructor(rno,fname,lname){
       this.rno = rno
       this.fname = fname
       this.lname = lname
       console.log('inside constructor')
    }
    // Creating Setter method to inject value into object
    set rollno(newRollno){
       console.log("inside setter")
       this.rno = newRollno
    }
    set stdfName(studentFirstName){
        console.log("inside setter")
        this.fname = studentFirstName
     }
     set stdlName(studentLastName){
        console.log("inside setter")
        this.lname = studentLastName
     }
 }
 let s1 = new Student(1,'Tarkeshwar','Barua')
 console.log(s1)
 //setter is called
 s1.rollno = 201
 s1.stdfName("ABC")
 s1.stdlName("KBC")
 console.log(s1)