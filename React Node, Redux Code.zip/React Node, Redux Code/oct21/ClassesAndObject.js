class Car{
    // brandName is parameter in the constructor and this.brandName represents instance variable
    // instance variables will be created automatically ondemand
    constructor(brandName){
        this.brandName=brandName
    }
    displayMyCar(){  // method of the class car
        console.log(this.brandName+" is my car")
    }
}
let myCar=new Car("Maruti")
console.log("I have a car from "+myCar.brandName)
myCar.displayMyCar()
export default Car

