function getUsers() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve([
                { username: 'tbarua1', email: 'tbarua1@gmail.com' },
                { username: 'tarkeshwar', email: 'tarkeshwar.b@regexsoftware.com' },
            ]);
            reject(new Error("Call can't be make successfull"));
        }, 2000);
    });
}
// will invoke while call will be fulfilled
function onFulfilled(users) {
    console.log(users);
}

const promise = getUsers();
promise.then(onFulfilled);