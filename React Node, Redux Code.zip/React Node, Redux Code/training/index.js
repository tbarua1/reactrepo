alert("Hey i am learning JAvaScript"); //Only for GUI
console.log("JavaScript is an interptreted language" )
