var x = 10; // JavaScript Approach
var a = 20; // TypeScript Approach
var y = 20;
var z = x + y;
console.log(z);
var fullName = "Dr Tarkeshwar Barua";
///fullName=34345345
var b = [4, 5, 7, 3, 6, 87, 4, 7, 6, 78];
b = "Hi";
