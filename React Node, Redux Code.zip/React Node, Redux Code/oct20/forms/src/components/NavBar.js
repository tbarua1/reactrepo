export default function NavBar(){
    return(
        <nav>
            <a href="/">Home</a> | 
            <a href="/MyForm">MyForm</a> | 
            <a href="/MyFormMultiple">MyFormMultiple</a> | 
            <a href="/MyFormComponent">MyFormComponent</a> | 
            <a href="/MyFormSubmit">MyFormSubmit</a> | 
            <a href="/MyFormTextArea">MyFormTextArea</a> | 
        </nav>
    )
}