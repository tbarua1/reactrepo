import { useState } from "react";

export default function MyFormComponent() {
    const [name, setName] = useState(""); 
    // useState is a hook that will maintain a state across the application
    // useState function is used to assign a default value to the variable create on left hand side
  // setName is a setter method for variable name
    return (
      <form>
        <label>Enter your name:
          <input
            type="text" 
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </label>
        <p>{name}</p>
      </form>
    )
  }