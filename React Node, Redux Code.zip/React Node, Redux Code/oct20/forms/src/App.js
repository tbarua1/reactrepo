import logo from './logo.svg';
import './App.css';
import MyForm from './components/FormsComponent';
import MyFormComponent from './components/MyFormComponent';
import MyFormSubmit from './components/SubmitAForm';
import MyFormMultiple from './components/MultipleElement';
import MyFormTextArea from './components/TextAreaForm';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import NavBar from './components/NavBar';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      <NavBar></NavBar>
      </header>
    
    </div>
        
  );
}

export default App;
