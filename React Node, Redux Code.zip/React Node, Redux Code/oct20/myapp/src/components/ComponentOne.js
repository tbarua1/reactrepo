export default function ComponentOne(){
    return <h1> I am from Component One</h1>
}