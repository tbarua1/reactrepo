import React from "react" // built in library
class Greetings extends React.Component{
    state ={
        name:"Tarkeshwar"  // this will be the default value in the state
    }
    updateName=()=>{
        this.setState({name:"Dr Tarkeshwar Barua"})
    }
    render(){
        return(
            <>
               <h1> {this.state.name}</h1>
               <button onClick={this.updateName}>Click Here to change Name</button>
            </>
        )
    }
}
export default Greetings;