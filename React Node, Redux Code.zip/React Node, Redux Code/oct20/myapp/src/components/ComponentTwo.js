import ComponentOne from "./ComponentOne";

export default function ComponentTwo(){
    return (
        <>    <h1> I am from Component Two</h1>
        <ComponentOne/>
        </>
) 
}