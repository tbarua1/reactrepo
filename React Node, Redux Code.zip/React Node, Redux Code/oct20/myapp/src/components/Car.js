import React from "react"
class Car extends React.Component{
    constructor(props){
        super(props)
        this.state={
            model:"Safari",
            brand:"TATA",
            colour:"red"
        }
    }
    changeCarState=()=>{
        this.setState({model:"nano"})
        this.setState({colour:"white"})
    }
    render(){
        return(
            <>
                <h1>My Car is {this.state.model} in {this.state.colour} from {this.state.brand}</h1>
                <button onClick={this.changeCarState}>Click Here to Change Car State</button>
            </>
        )
    }
    
}
export default Car;