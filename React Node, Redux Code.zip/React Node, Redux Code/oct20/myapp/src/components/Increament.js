import React from "react" // built in library
class Increament extends React.Component{
    state ={
        num:1  // this will be the default value in the state
    }
    updateValue=()=>{
       //this.setState(prevState => ({ num: num + 1 }));
       // this.setState({num:this.state.num+1})
        this.setState(({ num }) => ({ num: num + 1 }));
    }
    render(){
        return(
            <>
               <h1> {this.state.num}</h1>
               <button onClick={this.updateValue}>Click Here to change Value</button>
            </>
        )
    }
}
export default Increament;