import React from 'react';
class NewComponent extends React.Component {
  constructor(props) {
    super(props);
    // We declare the state as shown below
    this.state = {                           
      x: "This is x from state",    
      y: "This is y from state"
    }
  }
changeMyState=()=>{
        this.setState({x:"This is x from state changed"})
        this.setState({y:"This is x from state Changed"})
    }
  render() {
    let x1 = this.state.x;
    let y1 = this.state.y;
    return (
      <div>
        <h1>{x1}</h1>
        <h2>{y1}</h2>
        <button onClick={this.changeMyState}>Click Here</button>
      </div>
    );
  }
}
export default NewComponent;