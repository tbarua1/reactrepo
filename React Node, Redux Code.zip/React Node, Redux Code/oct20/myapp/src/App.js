import './App.css';
import Greetings from './components/Greetings';
import Car from "./components/Car"
import NewComponent from './components/NewComponent';
import Increament from './components/Increament';
import Garage from './components/InnerComponet';
import ComponentTwo from './components/ComponentTwo';
import Football from './components/Football';
import FootballWithArgument from './components/FootballWithArgument';
import FootballParams from './components/FootballMoreParam';
import ListCarInGarage from './components/ReactList';
import GarageKeyValue from './components/KeyValueComponent';
function App() {
  return (
    <div className="App">
      <header className="App-header">
       <Greetings></Greetings>
       <Car></Car>
       <NewComponent/>
       <Increament/>
       <Garage/>
       <ComponentTwo/>
       <Football/>
       <FootballWithArgument/>
       <FootballParams/>
       <ListCarInGarage/>
       <GarageKeyValue/>
      </header>
    </div>
  );
}

export default App;
