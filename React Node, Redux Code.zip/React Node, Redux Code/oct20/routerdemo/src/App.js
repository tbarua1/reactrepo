import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import MyForm from './components/FormsComponent';
import MyFormMultiple from './components/MultipleElement';
import MyFormComponent from './components/MyFormComponent';
import MyFormTextArea from './components/TextAreaForm';
import NavBar from './components/NavBar';
import SubmitAForm from './components/SubmitAForm';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <BrowserRouter>
          <NavBar></NavBar>
          <Routes>
            <Route path='/MyForm' element={<MyForm></MyForm>}></Route>
            <Route path='/MyFormMultiple' element={<MyFormMultiple></MyFormMultiple>}></Route>
            <Route path='/MyFormComponent' element={<MyFormComponent></MyFormComponent>}></Route>
            {/* <Route path='/MyFormSubmit' element={<MyFormSubmit></MyFormSubmit>}></Route> */}
            <Route path='/MyFormTextArea' element={<MyFormTextArea></MyFormTextArea>}></Route>
            <Route path='/SubmitAForm' element={<SubmitAForm></SubmitAForm>}></Route>
          </Routes>
        </BrowserRouter>
      </header>
    </div>
  );
}

export default App;
