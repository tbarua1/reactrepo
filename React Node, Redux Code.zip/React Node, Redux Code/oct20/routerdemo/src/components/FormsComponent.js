import "../css/mystyle.css"
import styles1 from "../css/my-style.module.css"

export default function MyForm() {
  const myStyle = {
    color: "white",
    backgroundColor: "DodgerBlue",
    padding: "10px",
    fontFamily: "Sans-Serif"
  };
  return (
    <>
      <form>
        <label>Enter your name:
          <input type="text" />
        </label>
      </form>
      <h1 style={{ color: "red" }}>Hello Style!</h1>
      <h1 style={{ backgroundColor: "lightblue" }}>Hello Style!</h1>
      <h1 style={myStyle}>Hello Style!</h1>
      <p>This paragraph is styled by using external css</p>
      <p className="bigblue">This paragraph is styled by using external css module</p>
    </>
  )
}