// initializing state for store
const initialState = {
    count: 1,
    title: "My Counter",
    isLoading: false,
    items: [],
    hasError: false  // 
}
// assigning a initial object in the created store 
const counterReducer = (state = initialState, action) => {
    switch (action.type) {
        case "INCREAMENT":
            return {
                ...state,  // spread operator 
                count: state.count + action.payload
            }
        case "DECREAMENT":
            return {
                ...state,
                count: state.count - action.payload
            }
        default:
            return state
    }
}
export default counterReducer