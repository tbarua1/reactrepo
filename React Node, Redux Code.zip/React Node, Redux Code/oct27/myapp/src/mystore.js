import { createStore } from 'redux';
import reducer from './reducers/reducer'
//const store = createStore(reducer);
const store =createStore(reducer, [preloadedState], [enhancer])
store.getState()
store.dispatch({type:'ITEMS_REQUEST'})
store.subscribe(()=>{ console.log(store.getState());})
const unsubscribe = store.subscribe(()=>{console.log(store.getState());});
unsubscribe();
