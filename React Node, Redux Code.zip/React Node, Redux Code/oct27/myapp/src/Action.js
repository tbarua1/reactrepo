// functions to perform an action
const increament = () => {
    return {
        type: "INCREAMENT",
        payload: 1
    }
}
const decreament = () => {
    return {
        type: "DECREAMENT",
        payload: 1
    }
}
export { increament, decreament }