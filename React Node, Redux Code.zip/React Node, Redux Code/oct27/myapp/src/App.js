import logo from "./logo.svg";
import "./App.css";
import { useDispatch, useSelector } from "react-redux";
import { decreament, increament } from "./Action";

function App() {
  const dispatch = useDispatch(); // to sendaction to reducer
  const counter = useSelector((state) => state.count); 
  // set initial value to the store before and after making update
  return (
    <div className="App">
      <header className="App-header">
        <button  onClick={ () => { dispatch(increament()); console.log("Count Value ", counter); }}>+</button>
        {counter}
        <button onClick={ () => { dispatch(decreament()); console.log("Count Value ", counter);} }> - </button>
      </header>
    </div>
  );
}
export default App;