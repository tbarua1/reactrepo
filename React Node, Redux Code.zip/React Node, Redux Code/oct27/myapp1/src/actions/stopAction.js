export const stopAction={
    type:"rotate",
    payload:false
}