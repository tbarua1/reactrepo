import logo from './logo.svg';
import './App.css';
import logoimage from "./Capture.PNG"
import { useState } from 'react';
import Add from './components/Create';
import UpdateRecord from './components/Update';
import ListingRecord from './components/Listing';
import Todo from './components/Todo';
const authOptions={
  clientName: "My Application",
}
function App() {
  const [oidcIssuer, setOidcIssuer]=useState("") // setting state as blank list to display record
  const handleChange = (events)=>{
    setOidcIssuer(events.target.value)
  }
  return (
    <div className="App">
      <header className="App-header">
<ListingRecord></ListingRecord>
<Add></Add>
<UpdateRecord></UpdateRecord>
<Todo></Todo>
        <span>
          Login with:
          <input type="text" name='oidcIssuer' value={oidcIssuer} list="providers" onChange={handleChange}></input>
          <datalist id="providers">
            <option value="http://google.com"></option>
            <option value="http://yahoo.com"></option>
          </datalist>
          <input type="submit"name='submitbtn' value="Submit Button"></input>
        </span>
      </header>
    </div>
  );
}

export default App;
