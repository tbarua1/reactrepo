export default function UpdateRecord(){
    return <button>Update Record</button>
}