export default function ListingRecord(){
    return <button>Listing Record</button>
}