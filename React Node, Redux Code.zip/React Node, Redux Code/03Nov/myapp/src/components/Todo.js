import { useState } from "react"
import CreateTask from "./Create"
import "./mycss.css"

function Task({ task }) {
    // Displaying Props
    return (
        <div className="task" style={{ textDecoration: task.completed ? "line-through" : "" }}>
            {task.title}
        </div>
    )
}
function Todo() {
    const [tasks, setTasks] = useState([
        {
            title: "Task-1",
            completed: false
        },
        {
            title: "Task-2",
            completed: true
        },
        {
            title: "Task-3",
            completed: false
        },
        {
            title: "Task-4",
            completed: true
        },
        {
            title: "Task-5",
            completed: false
        }
    ])
    const addTask = title => {
        const newTasks = [...tasks, { title, completed: false }]
        setTasks(newTasks)
    }
   

    return (
        <div className="item-container">
            <div className="header1">Items</div>
            <div className="task2">
                {
                    tasks.map((t, index) =>
                        <Task task={t} index={index} key={index}></Task>
                    )

                }
            </div>
           <CreateTask></CreateTask>
        </div>

    )
}
export default Todo;