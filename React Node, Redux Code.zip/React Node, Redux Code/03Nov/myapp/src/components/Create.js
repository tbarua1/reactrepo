import { useState } from "react"
import {tasks, setTasks} from "./Todo"

export default function CreateTask({addTask}){
    const [value, setValue] = useState("")
    const handleSubmit = e => {
        e.preventDefault(); if (!value) return
        addTask(value)
        setValue("")
    }
    return (
        <form onSubmit={handleSubmit}>
            <input type="text" className="input" value={value} placeholder="Add a new Task " 
            onChange={e=>setValue(e.target.value)}></input>
        </form>
    )
}