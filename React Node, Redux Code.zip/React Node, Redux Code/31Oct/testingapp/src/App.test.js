import { render, screen } from '@testing-library/react';
import testForAdd from './addition';
import App from './App';
import addtion from './addition';
import mathOperations from './Calculator';

test('renders learn react link', () => {
  render(<App />);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});


test('Addition Test ',function(){
  expect(9).toBe(9)
})
test("another test",()=>{
  expect(addtion(2,2)).toBe(4)
})


test("Test that 1 + 2 = 3", () => {
  const num1 = 1;
  const num2 = 2;
  const result = num1 + num2; //3
 
  expect(result).toBe(3);
});


test("subtraction ",()=>{
  expect(mathOperations.subtraction(5,2)).toBe(3)
})