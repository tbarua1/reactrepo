export default function addtion(a,b){
    return a+b
}