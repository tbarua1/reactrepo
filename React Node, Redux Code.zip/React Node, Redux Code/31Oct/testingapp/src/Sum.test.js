//import sum from "./sum"
const sum = require('./sum');

test('adds 1 + 2 to equal 3', () => {
    expect(sum(1, 2)).toBe(3);
});
test('adds 2 + 2 to equal 4', () => {
    expect(sum(2, 2)).toBe(4);
});

//no need to import anything for test
// Following are the white hat/black hat testing library
// // we can do performance testing too with jest library
//Jest,react-scripts,Enzyme,Cypress