function sum(a, b) {
    return a + b;
}
module.exports = sum; // this is my component/module for test