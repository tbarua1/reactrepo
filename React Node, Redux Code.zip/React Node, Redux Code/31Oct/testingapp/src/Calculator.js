const mathOperations = {
    sum: function(a, b) {
        return a + b
    },
    subtraction: function(a, b) {
        return a - b
    },
    multiplication: function(a, b) {
        return a * b
    },
    division: function(a, b) {
        return a / b
    },
    module: function(a, b) {
        return a % b
    }
}
module.exports = mathOperations;
// here mathOperations is a JSON object that can store any type of objects