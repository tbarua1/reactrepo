describe("Testing Sum", () => {
    function sum(a, b) {
        return a + b;
    }
    it("should equal 4", () => {
        expect(sum(2, 2)).toBe(4);
    })
    test("also should equal 4", () => {
        expect(sum(2, 2)).toBe(4);
    })
    it("should equal 4", () => {
        expect(sum(2, 2)).toBe(4); // toBe is known as matcher for test case
    })
})
//describe wraps it and test function, this is the way ofgroup our test.it and test both are keyword. sequesnce of the it and test can be interchangible