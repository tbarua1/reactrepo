import logo from './logo.svg';
import './App.css';
import { ApolloClient, InMemoryCache } from '@apollo/client';
import { gql } from '@apollo/client';
function App() {

const client = new ApolloClient({
    uri: 'http://localhost:4000/graphql',
    cache: new InMemoryCache(),
});

client
  .query({
    query: gql`
      query ExampleQuery{
        hello
      }
    `
  })
  .then(result => console.log(result));
  
  return (
    <div className="App">
      <header className="App-header">
        <h1>I am learning GraphQL</h1>
      </header>
    </div>
  );
}

export default App;
