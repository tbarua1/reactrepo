function testForAdd(a,b){
    return a+b
}
module.export = testForAdd