//import testForAdd from "index"
//var testForAdd=require("index")
test('Addition Test ',function(){
    expect(testForAdd(4,5)).toBe(9)
})
