const functions = {
    add: (num1, num2) => num1 + num2,
    isNull: () => null,
    checkValue: val => val,
    createCar: () => {
        const car = {
            make: "Maruti",
            model: "WagonR"
        }
        return car
    }
}
module.export = functions;