const express = require("express")
const app = express();
const myjson=[{
    "id":1,
    "name":"Tarkeshwar",
    "phone":"4543543"
},
{
    "id":2,
    "name":"ABC",
    "phone":"33333"
},
{
    "id":3,
    "name":"KBC",
    "phone":"5555"
}
]
app.get("/",(req,res)=>{
    res.send(myjson)
})
app.listen(7000)