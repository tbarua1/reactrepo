var express =require ("express") // to create server
const { graphqlHTTP } = require("express-graphql") // to install graphql features in server
var {buildSchema} = require("graphql") // to make query to graphql server
var schema = buildSchema(`
    type Query {
        hello: String 
    }
`)
var root = {
    hello:()=>{
        return "Hello World"
    },
}
var app=express()
app.use("/graphql", graphqlHTTP({
    schema:schema,
    rootValue: root,
    graphiql:true,
}))
app.listen(4000)
console.log("Server got started on port 4000 with endpoint /graphql")