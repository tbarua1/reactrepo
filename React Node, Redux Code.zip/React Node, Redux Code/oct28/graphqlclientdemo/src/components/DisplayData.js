import { useState,useEffect } from "react"

export default function DisplayData() {
    const [data, setData] = useState([])
    const getData = () => {
        fetch("http://localhost:4000/graphql", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            body: JSON.stringify({ query: "{hello}" })
        })
            .then(function (r) {
                console.log(r)
                return r.json()
            })
            .then(function (data) {
                console.log("Data : " + data);
                setData(data)
            }
            )
    }
    useEffect(() => {
        getData()
    }, [])
    return (<h1>{data && data.length>0 && data.map((item)=>{
        <p>{item}</p>
    })}Sample Data  </h1>)
}