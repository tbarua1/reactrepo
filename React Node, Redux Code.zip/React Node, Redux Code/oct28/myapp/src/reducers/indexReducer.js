import { combineReducers } from "redux";

export default combineReducers({
    todos,
    visibilityfi
})