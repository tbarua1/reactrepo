import {addTodo, setVisibilityFilter, toggleTodo,VisibilityFilters} from "./indexAction"
describe("tot actions",()=>{
    it("addTodo should creat by ADD_TODO action ",()=>{
        expect(addTodo("Use Redux")).toEqual({
            type:"ADD_TODO",
            id:0,
            text:"Use Redux in React"
        })
    })
    it("setVisibilityFilters should be created by setVisibilityFilters ",()=>{
        expect(setVisibilityFilter("active")).toEqual({
            type:"SET_VISIBILITY_FILTER",
            filter:"active"
        })
    })
    it("toggleTodo should be created TOGGLE_TODO action",()=>{
        expect(toggleTodo(1)).toEqual({
            type:"TOGGLE_TODO",
            id:1
        })
    })
})