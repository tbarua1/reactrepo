class Employee1 { 
    name:string; 
    constructor(name:string) { 
       this.name = name; 
    }   
    display():void { 
       console.log("Employee Name: "+this.name);
    } 
 }
 var obj2 = new Employee1("Jai");
 console.log("Employee Name: "+obj2.name);  
 obj2.display();