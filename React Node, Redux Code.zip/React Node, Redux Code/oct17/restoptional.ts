function showNames(...names:string[]) {    
    for(var i = 0;i<names.length;i++) { 
       console.log(names[i]);
    } 
} 
showNames();
showNames("Rajeev");
 showNames("Rajeev","Gunjan","Vikram","Asmita"); 
 showNames("Mahesh", "Jai", "Narender", "Vishal", "Hemant");