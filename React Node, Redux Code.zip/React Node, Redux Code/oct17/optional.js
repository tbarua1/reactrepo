function dispDetails(fname, lname) {
    console.log("Fisrt Name", fname);
    if (lname != undefined)
        console.log("Last Name", lname);
}
dispDetails("Asmita");
dispDetails("Nidhi", "Gupta");
