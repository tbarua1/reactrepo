var avg = 20;
var percentage = 90;
console.log("Value of avg: " + avg + " ,value of percentage: " + percentage);
var result123 = ((avg > 50) && (percentage > 80));
// false && true   = False
console.log("(avg>50)&&(percentage>80): ", result123);
var result2123 = ((avg > 50) || (percentage > 80));
//false || true   = True
console.log("(avg>50)||(percentage>80): ", result2123);
var result3123 = !((avg > 50) && (percentage > 80));
//      false && true = false  =  True
console.log("!((avg>50)&&(percentage>80)): ", result123);
// CTRL + + To Zoom
// CTRL + - to Zoom out
