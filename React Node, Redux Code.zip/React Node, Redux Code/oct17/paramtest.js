function paramTest(rollNo, name) {
    console.log(rollNo);
    console.log(name);
}
paramTest(645, "Tarkeshwar");
