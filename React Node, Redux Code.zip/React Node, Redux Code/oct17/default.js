function displayDetails1(name, sport) {
    if (sport === void 0) { sport = "Cricket"; }
    console.log("Name: " + name + ", Sport: " + sport);
}
displayDetails1("Jai");
displayDetails1("Vivek", "Football");
