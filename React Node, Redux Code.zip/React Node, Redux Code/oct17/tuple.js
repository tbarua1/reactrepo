function tupleTest(values) {
    for (var i = 0; i < values.length; i++) {
        console.log(values[i]);
    }
}
var values = [10, 20, "Gunjan", "Rajeev", "Vikram", "Sudhir"];
values[3] = "Tarkeshwar";
tupleTest(values);
