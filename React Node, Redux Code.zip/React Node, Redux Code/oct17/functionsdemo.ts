function greet(person:string | string[]):string | string[]{
    if(typeof person==='string'){
        return `Hello, ${person} !`
    }
    else if(Array.isArray(person)){
         return person.map(temp=> `Hello, ${temp} !`);
    }
    throw new Error("Invalid Data passed into function")
      // JSX Expression
}
let myname=greet(["Tarkeshwar", "Barua", "xyz", "abc"])
console.log(myname);