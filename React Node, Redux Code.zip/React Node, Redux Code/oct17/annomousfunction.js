var annonfunc = function (fname, lname) {
    return "Hi I am " + fname + " " + lname;
};
var data = annonfunc("Tarkeshwar", "Barua");
console.log(data);
