function booleanTest(bVar:boolean):void{
    console.log(bVar.valueOf()); 
  }
  var boolean1:boolean= true;//new Boolean(true);
  var boolean2:boolean=false // new Boolean(false); 
  var boolean3:boolean=true;
  booleanTest(boolean1);
  booleanTest(boolean2);
  booleanTest(boolean3);