function greeting(fname:string,lname:string):string{
    console.log("Good Evening " + fname+" "+lname);
    return "Good Evening " + fname+" "+lname;
}
let msg:string=greeting("Dr Tarkeshwar", "Barua")
console.log("print Message " +msg);
