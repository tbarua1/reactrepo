function greeting(fname, lname) {
    console.log("Good Evening " + fname + " " + lname);
    return "Good Evening " + fname + " " + lname;
}
var msg = greeting("Dr Tarkeshwar", "Barua");
console.log("print Message " + msg);
