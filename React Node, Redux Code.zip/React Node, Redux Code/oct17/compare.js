var num3:number = 15;
var num4:number = 17; 
console.log("Value of num1: "+num1); 
console.log("Value of num2 :"+num2);
var result = num1>num2 
console.log("num1 greater than num2: "+result)
result = num1<num2 
console.log("num1 lesser than num2: "+result)  
result = num1>=num2 
console.log("num1 greater than or equal to  num2: "+result)
result = num1<=num2
console.log("num1 lesser than or equal to num2: "+result)  
result = num1==num2 
console.log("num1 is equal to num2: "+result)  
result = num1!=num2  
console.log("num1 is not equal to num2: "+result)