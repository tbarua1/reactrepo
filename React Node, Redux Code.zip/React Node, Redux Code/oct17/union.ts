function unionTest(value:string|number):void{
    console.log(value); 
  }
  unionTest("Jai");
  unionTest(123);