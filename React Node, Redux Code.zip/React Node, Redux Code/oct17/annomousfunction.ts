let annonfunc=function(fname:string, lname:string):string{
    return "Hi I am "+fname + " "+lname;
}
let data =annonfunc("Tarkeshwar","Barua");
console.log(data);