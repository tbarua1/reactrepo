var Greeting = /** @class */ (function () {
    function Greeting(message) {
        this.message = message;
    }
    Greeting.prototype.greet = function (person) {
        var _this = this;
        if (typeof person === 'string') {
            return "Hello, ".concat(this.message, ", ").concat(person);
        }
        else if (Array.isArray(person)) {
            return person.map(function (tempName) { return "Hello ".concat(_this.message, " , ").concat(tempName); });
        }
        throw new Error("Invalid Argument");
    };
    return Greeting;
}());
var hello = new Greeting("Hi");
console.log(hello);
var hello1 = hello.greet("Tarkeshwar");
console.log(hello1);
var hello2 = hello.greet(["Dr", "Tarkesh", "Barua"]);
console.log(hello2);
