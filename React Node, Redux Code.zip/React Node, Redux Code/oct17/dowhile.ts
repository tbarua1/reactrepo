let printnum:number=0; // initialization of variable
do{
    console.log(printnum) // print number first
    printnum++;
}while(printnum<10); // cheking condition

//===============================While Loop=============================

let whilenum:number = 0; // initialization
while(whilenum<10){ // cheking condition
    console.log(whilenum);
    whilenum+=1;
}
