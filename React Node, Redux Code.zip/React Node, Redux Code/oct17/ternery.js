var num = 1;
if (num > 0) {
    console.log("Positive");
}
else if (num < 0) {
    console.log("Negative");
}
else {
    console.log("Given number is Zero");
}
//var tenery = num > 0 ?"positive":"negative" ;
console.log("Program Done");
