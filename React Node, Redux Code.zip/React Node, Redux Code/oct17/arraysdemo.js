function arrayTest(names) {
    for (var i = 0; i < names.length; i++) {
        console.log(names[i]);
    }
}
var names = ["Bharat", "Sahdev", "Richi", "Harish", "Bharti", "Deepika", "Shaveta"];
arrayTest(names);
