function varTest(){
    let num1 =10;	    
    console.log(num1);  //output 10
    if(true){
     let num2=20;       
     console.log(num2); //output 20
    }
    console.log(num1);  //output 10
    //console.log(num2);  //can't be printed because num2 only available inside if block
  }
  varTest()