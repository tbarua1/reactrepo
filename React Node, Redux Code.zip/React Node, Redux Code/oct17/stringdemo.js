//Constructor, length, prototype, charAt(), charCodeAt(), concat(), indexOf(), lastIndexOf(), localeCompare(), match(), replace(), search(), slice(), split(), substr(), substring(), toLocaleLowerCase()
function stringTest(str) {
    console.log(str);
}
var str = "Sahdev";
stringTest(str);
console.log(str.length);
var myname1 = String("Dr Tarkeshwar Barua"); // creating object using string constructor
console.log(myname1.charAt(10));
var fname = "Tarkeshwar";
var lname = "Barua";
var fullname = fname.concat(lname);
console.log(fullname);
