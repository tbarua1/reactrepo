function numberprint(num : number):number{
    console.log("The number you have entered "+ num)
    return num;
}
let sampleNumber= numberprint(15);
console.log(sampleNumber)