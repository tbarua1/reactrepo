var calculateSquare = function (num) {
    num = num * num;
    console.log(num);
    return num;
};
var value = calculateSquare(10);
console.log(value);
