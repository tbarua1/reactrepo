interface IPerson { 
    firstName:string, 
    lastName:string, 
    sayHi: ()=>string 
 }
 //==================================IPerson.ts=============================================  
 var customer:IPerson = {  // Implementing IPerson interface to customer variable
    firstName:"Ajay",
    lastName:"Laddha", 
    sayHi: ():string =>{return "Hi"} 
 }  
 console.log("Customer Object Details: ");
 console.log(customer.sayHi()); 
 console.log(customer.firstName); 
 console.log(customer.lastName);

//===================================employee.ts========================  
var employee:IPerson = { 
    firstName:"Vikas",
    lastName:"Jainer", 
    sayHi: ():string =>{return "Hello"} 
 } 
  
 console.log("Employee  Object Details: ");
 console.log(employee.sayHi());
 console.log(employee.firstName);
 console.log(employee.lastName)