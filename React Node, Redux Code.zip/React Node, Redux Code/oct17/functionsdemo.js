function greet(person) {
    if (typeof person === 'string') {
        return "Hello, ".concat(person, " !");
    }
    else if (Array.isArray(person)) {
        return person.map(function (temp) { return "Hello, ".concat(temp, " !"); });
    }
    throw new Error("Invalid Data passed into function");
    // JSX Expression
}
var myname = greet(["Tarkeshwar", "Barua", "xyz", "abc"]);
console.log(myname);
