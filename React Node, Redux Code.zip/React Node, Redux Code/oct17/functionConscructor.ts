let myFunction = new Function("num1", "num2", "return num1 + num2"); 
console.log(myFunction(10, 15)); 
