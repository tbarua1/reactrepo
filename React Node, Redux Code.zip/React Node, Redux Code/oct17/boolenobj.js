function booleanTest(bVar) {
    console.log(bVar.valueOf());
}
var boolean1 = true; //new Boolean(true);
var boolean2 = false; // new Boolean(false); 
var boolean3 = true;
booleanTest(boolean1);
booleanTest(boolean2);
booleanTest(boolean3);
