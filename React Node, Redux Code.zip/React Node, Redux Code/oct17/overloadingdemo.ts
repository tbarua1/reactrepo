function greet(person:string) :string;     // expression
function greet(person:string[]) :string[];

// implementation of Signature 
function greet(person:unknown) : unknown{ 
    if(typeof person === 'string'){
        return `HEllo ${person}`
    }else if(Array.isArray(person)){
        return person.map(temp => `HEllo ${temp}`)
    }
    throw new Error("Invalid Data ")
} 
let greetResult=greet("Dr Tarkeshwar Barua")
console.log(greetResult)
let greetResult1=greet(["Dr", "Tarkeshwar", "Barua","abc","xyz"])
console.log(greetResult1)
