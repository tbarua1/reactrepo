// implementation of Signature 
function greet(person) {
    if (typeof person === 'string') {
        return "HEllo ".concat(person);
    }
    else if (Array.isArray(person)) {
        return person.map(function (temp) { return "HEllo ".concat(temp); });
    }
    throw new Error("Invalid Data ");
}
var greetResult = greet("Dr Tarkeshwar Barua");
console.log(greetResult);
var greetResult1 = greet(["Dr", "Tarkeshwar", "Barua", "abc", "xyz"]);
console.log(greetResult1);
