function unionTest(value) {
    console.log(value);
}
unionTest("Jai");
unionTest(123);
