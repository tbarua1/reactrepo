interface IPerson { 
    age:number;
    name:string;
 }  
 interface IEmployee { 
    empId:string; 
 }  
 interface Engineer extends IPerson, IEmployee {} 
 let obj1 = {name:"Asmita", age:32, empId:"EMP023"}; 
 console.log("Name:  "+obj1.name);
 console.log("Age:  "+obj1.age);
 console.log("Emp Id:  "+obj1.empId);