let calculateSquare = (num:number)=> {    
    num = num * num; 
    console.log(num); 
    return num;
 } 
 let value:number=calculateSquare(10);
 console.log(value);