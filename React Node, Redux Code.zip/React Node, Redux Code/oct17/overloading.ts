function showDetails10(name: string): void {
  console.log(name);
}
function showDetails20(empId: number): void {
  console.log(empId);
}
showDetails10("Jai")
showDetails20(123);