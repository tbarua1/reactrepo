function arrayTest1(names) {
    for (var i = 0; i < names.length; i++) {
        console.log(names[i]);
    }
}
var names1 = new Array("Jai", "Vivek", "Mahesh", "Narender", "Vishal", "Hemant");
arrayTest1(names1);
