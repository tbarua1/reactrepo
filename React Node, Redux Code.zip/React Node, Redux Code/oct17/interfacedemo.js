//==================================IPerson.ts=============================================  
var customer = {
    firstName: "Ajay",
    lastName: "Laddha",
    sayHi: function () { return "Hi"; }
};
console.log("Customer Object Details: ");
console.log(customer.sayHi());
console.log(customer.firstName);
console.log(customer.lastName);
//===================================employee.ts========================  
var employee = {
    firstName: "Vikas",
    lastName: "Jainer",
    sayHi: function () { return "Hello"; }
};
console.log("Employee  Object Details: ");
console.log(employee.sayHi());
console.log(employee.firstName);
console.log(employee.lastName);
