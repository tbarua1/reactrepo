function varTest(){
    var num1 =10;	    
    console.log(num1);  //output 10
    if(true){
     var num2=20;       
     console.log(num2); //output 20
    }
    console.log(num1);  //output 10
    console.log(num2);  //output 20
  }
  varTest();
 // console.log(num1);  //useful only inside function
  //console.log(num2);  ////useful only inside function
