var num1:number = 20;
var num2:number = 4;
var result:number = 0; 
result = num1 + num2;
console.log("Sum: "+result); 
result = num1 - num2; 
console.log("Difference: "+result);
result = num1*num2;
console.log("Product: "+result); 
result = num1/num2;
console.log("Quotient: "+result); 
result = num1%num2;
console.log("Remainder: "+result); 
num1++ 
console.log("Value of num1 after increment: "+num1);
num2-- 
console.log("Value of num2 after decrement: "+num2);