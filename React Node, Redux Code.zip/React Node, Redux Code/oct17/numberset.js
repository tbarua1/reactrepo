function numberprint(num) {
    console.log("The number you have entered " + num);
    return num;
}
var sampleNumber = numberprint(15);
console.log(sampleNumber);
