function arrayTest1(names:string[]):void{
    for (let i=0;i<names.length;i++){  
      console.log(names[i]); 
    }
  }
  var names1:string[] = new Array("Jai","Vivek","Mahesh","Narender","Vishal","Hemant");
  arrayTest1(names1);