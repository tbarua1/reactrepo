function numTest(num1) {
    console.log(num1);
}
var num10 = new Number(123);
var num20 = new Number("Hello");
numTest(num10);
numTest(num20);
