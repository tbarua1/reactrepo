var Employee1 = /** @class */ (function () {
    function Employee1(name) {
        this.name = name;
    }
    Employee1.prototype.display = function () {
        console.log("Employee Name: " + this.name);
    };
    return Employee1;
}());
var obj2 = new Employee1("Jai");
console.log("Employee Name: " + obj2.name);
obj2.display();
