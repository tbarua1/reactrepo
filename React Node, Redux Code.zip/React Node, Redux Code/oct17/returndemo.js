function getMessage() {
    return "Hello World!";
}
function sayHello() {
    var msg = getMessage();
    console.log(msg);
}
sayHello();
