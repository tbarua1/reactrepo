function arrayTest(names:string[]):void{
    for(let i=0;i<names.length;i++){  
      console.log(names[i]); 
    }
  }
  var names:string[] = ["Bharat","Sahdev","Richi","Harish","Bharti","Deepika","Shaveta"];
  arrayTest(names);