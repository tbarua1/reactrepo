var person = { Fname: "Rajeev", Lname: "Johari", Age: 40 }; // JSON Object 
var perproperty;
for (perproperty in person) {
    console.log(perproperty + ": " + person[perproperty]);
}