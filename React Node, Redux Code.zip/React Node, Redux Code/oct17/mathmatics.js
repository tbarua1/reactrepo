function mathTest(num) {
    var squarRoot = Math.sqrt(num);
    console.log("Random Number:  " + num);
    console.log("Square root:  " + squarRoot);
}
var num = Math.random();
console.log(num);
mathTest(num);
