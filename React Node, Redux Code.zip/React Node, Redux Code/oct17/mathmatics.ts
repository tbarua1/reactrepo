function mathTest(num:number):void{
    var squarRoot = Math.sqrt(num);
    console.log("Random Number:  " + num); 
    console.log("Square root:  " + squarRoot); 
  }
  var num:number = Math.random();
  console.log(num)
  mathTest(num);