var Employee2 = /** @class */ (function () {
    function Employee2() {
    }
    return Employee2;
}());
//function
var display = function (obj) {
    console.log("Employee Name: " + obj.name);
    console.log("Employee EmpId: " + obj.empId);
};
//create an object 
var obj10 = { name: "Jai", empId: "EMP024" };
//access the function
display(obj10);
