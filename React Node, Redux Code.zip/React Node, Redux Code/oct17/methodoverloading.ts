class Greeting{
    message:string
    constructor(message:string){ // to inject value to the variable
        this.message=message;
    }
    greet(person:string):string;
    greet(person:string[]):string[];
    greet(person:unknown):unknown{
        if(typeof person ==='string'){
            return `Hello, ${this.message}, ${person}`
        }else if(Array.isArray(person)){
            return person.map(tempName => `Hello ${this.message} , ${tempName}`)
        }
        throw new Error("Invalid Argument")
    }
}
let hello = new Greeting("Hi");
console.log(hello)
let hello1=hello.greet("Tarkeshwar");
console.log(hello1)
let hello2 = hello.greet(["Dr","Tarkesh","Barua"])
console.log(hello2)