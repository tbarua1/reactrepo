function paramTest(rollNo:number,name:string) { 
    console.log(rollNo);
    console.log(name);
 } 
 paramTest(645,"Tarkeshwar");