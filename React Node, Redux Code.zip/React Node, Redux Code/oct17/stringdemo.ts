//Constructor, length, prototype, charAt(), charCodeAt(), concat(), indexOf(), lastIndexOf(), localeCompare(), match(), replace(), search(), slice(), split(), substr(), substring(), toLocaleLowerCase()
function stringTest(str:string):void{
  console.log(str); 
}
var str:string = "Sahdev";
stringTest(str);
console.log(str.length)
let myname1=String("Dr Tarkeshwar Barua") // creating object using string constructor
console.log(myname1.charAt(10))
let fname="Tarkeshwar"
let lname="Barua"
let fullname=fname.concat(lname)
console.log(fullname)