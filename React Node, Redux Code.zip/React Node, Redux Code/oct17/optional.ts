function dispDetails(fname:string,lname?:string) {  
    console.log("Fisrt Name",fname); 
    if(lname!=undefined)  
    console.log("Last Name",lname); 
 }
 dispDetails("Asmita");
 dispDetails("Nidhi", "Gupta");