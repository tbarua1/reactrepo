function displayDetails1(name:string, sport:string = "Cricket") {  
    console.log("Name: " +name + ", Sport: "+ sport); 
 } 
 displayDetails1("Jai");
 displayDetails1("Vivek","Football");