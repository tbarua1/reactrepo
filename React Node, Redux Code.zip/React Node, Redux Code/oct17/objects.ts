class Employee2 { 
    //field 
    name:string; 
    empId:string;  
 } 
 //function
 var display = function(obj: {name:string, empId:string}) { 
   console.log("Employee Name: "+obj.name);
   console.log("Employee EmpId: "+obj.empId);
 }  
 //create an object 
 var obj10:Employee2 = {name:"Jai", empId:"EMP024"};
 //access the function
 display(obj10);