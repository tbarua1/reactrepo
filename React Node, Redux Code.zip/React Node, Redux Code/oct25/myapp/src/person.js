// person.js  In-line individually, or all at once at the bottom
export const name = "Tarkeshwar"
export const age = 35
//export { name, age }