import logo from './logo.svg';
import './App.css';
import { name,age } from './person'; // more then one object/variable/function can be import or export
import message from './defaultexport';// only one object/variable/function can be import or export

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>{name} - {age}</h1>
        <p>{message()}</p>
      </header>
    </div>
  );
}

export default App;
